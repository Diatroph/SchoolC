
public class Driver {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
	
		RightTriangle t = new RightTriangle(2, 3);	

	}

}
