﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week_10
{
    public class Technician
    {


        public int TechId
        {
            get; set;
        }


        public string Name { get; set; }
    }
}
