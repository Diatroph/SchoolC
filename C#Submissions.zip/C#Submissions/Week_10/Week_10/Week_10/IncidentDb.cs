﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week_10
{
    public class IncidentDb
    {
        private const string Dir = "..\\..\\";
        private const string Path = Dir + "Incidents.txt";

        public static List<Incident> GetIncidents()
        {
            List<Incident> incidents = new List<Incident>();
            FileStream fileStream = null;
            StreamReader textIn = null;

            try
            {

                fileStream = new FileStream(Path, FileMode.OpenOrCreate, FileAccess.Read);
                textIn = new StreamReader(fileStream);

                while (textIn.Peek() != -1)
                {
                    string row = textIn.ReadLine();
                    if (row != null)
                    {
                        string[] columns = row.Split('|');
                        Incident incident = new Incident
                        {
                            IncidentId = Convert.ToInt32(columns[0]),
                            CustomerId = Convert.ToInt32(columns[1]),
                            ProductCode = columns[2],
                            TechId = (columns[3] == "") ? Convert.ToInt32(null) : Convert.ToInt32(columns[3]),
                            DateOpened = Convert.ToDateTime(columns[4]),
                            DateClosed = (columns[5] == "") ? Convert.ToDateTime(null) : Convert.ToDateTime(columns[5]),
                            Title = columns[6],
                            Description = columns[7]

                        };
                        incidents.Add(incident);
                    }
                }

            }
            catch (FileNotFoundException)
            {
                MessageBox.Show(Path + " not found. ", "File Not Found");
            }
            catch (DirectoryNotFoundException)
            {
                MessageBox.Show(Dir + " not found. ", "Directory Not Found");
            }
            catch (IOException ex)
            {
                MessageBox.Show(ex.Message + "IOException");
            }
            finally
            {
                textIn.Close();
            }

            return incidents;

        }

        public static void SaveIncidents(List<Incident> incidents)
        {
            StreamWriter textOut = new StreamWriter(new FileStream(Path, FileMode.Create, FileAccess.Write));

            foreach(Incident incident in incidents)
            {
                textOut.Write(incident.IncidentId + "|");
                textOut.Write(incident.CustomerId + "|");
                textOut.Write(incident.ProductCode + "|");
                textOut.Write(incident.TechId + "|");
                textOut.Write(incident.DateOpened + "|");

                textOut.Write(incident.DateClosed + "|");
                textOut.Write(incident.Title + "|");
                textOut.WriteLine(incident.Description);
            }

            textOut.Close();
        }

    }
}
