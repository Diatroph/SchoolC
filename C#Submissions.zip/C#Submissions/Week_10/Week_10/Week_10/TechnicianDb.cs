﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace Week_10
{
    public class TechnicianDb
    {
        private const string Dir = "..\\..\\";

        private const string Path = Dir + "Technicians.txt";

        public static List<Technician> GetTechnicians()
        {
            List<Technician> technicians = new List<Technician>();
            FileStream fileStream = null;
            StreamReader textIn = null;

            try
            {

                fileStream = new FileStream(Path, FileMode.OpenOrCreate, FileAccess.Read);
                textIn = new StreamReader(fileStream);

                while (textIn.Peek() != -1)
                {
                    string row = textIn.ReadLine();
                    if (row != null)
                    {
                        string[] columns = row.Split('|');
                        Technician technician = new Technician
                        {
                            TechId = Convert.ToInt32(columns[0]),
                            Name = columns[1]
                        };
                        technicians.Add(technician);
                    }
                }

            }
            catch(FileNotFoundException)
            {
                MessageBox.Show(Path + " not found. ", "File Not Found");
            }
            catch(DirectoryNotFoundException)
            {
                MessageBox.Show(Dir + " not found. ", "Directory Not Found");
            }
            catch(IOException ex)
            {
                MessageBox.Show(ex.Message + "IOException");
            }
            finally
            { 
                textIn.Close();
            }

            return technicians;
        }

        public static void SaveTechnician(List<Technician> technicians)
        {
            StreamWriter textOut = new StreamWriter(new FileStream(Path, FileMode.Create, FileAccess.Write));

            foreach(Technician technician in technicians)
            {
                textOut.Write(technician.TechId + "|");
                textOut.WriteLine(technician.Name);
            }

            textOut.Close();

        }


    }
}
