﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week_10
{
    public partial class Form1 : Form
    {
        List<Technician> technicians = null;
        List<Incident> incidents = null;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
            LoadData();

        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            Incident incident = new Incident();
            incident.CustomerId = Convert.ToInt32(txtcustomerId.Text);
            incident.DateClosed = Convert.ToDateTime(dateTimeEnd.Value);
            incident.DateOpened = Convert.ToDateTime(dateTimeStart.Value);
            incident.Description = txtDescription.Text;
            incident.IncidentId = Convert.ToInt32(txtincidentId.Text);
            incident.ProductCode = txtProductCode.Text;
            incident.TechId = Convert.ToInt32(txtTechId.Text);
            incident.Title = txtProdutTitle.Text;

            incidents.Add(incident);
            IncidentDb.SaveIncidents(incidents);

            Technician technician = new Technician();
            technician.Name = txtTechName.Text;
            technician.TechId = Convert.ToInt32(txtTechId.Text);

            technicians.Add(technician);
            TechnicianDb.SaveTechnician(technicians);
            LoadData();

        }

        private void LoadData()
        {
            lvIncidents.Clear();
            technicians = TechnicianDb.GetTechnicians();
            incidents = IncidentDb.GetIncidents();

            var incidentsByTechs = from incident in incidents
                                   join tech in technicians
                                   on incident.TechId equals tech.TechId
                                   where incident.DateClosed != null
                                   orderby tech.Name, incident.DateOpened
                                   select new
                                   {
                                       tech.Name,
                                       incident.ProductCode,
                                       incident.DateOpened,
                                       incident.DateClosed,
                                       incident.Title
                                   };

            string techName = "";
            int i = 0;
            foreach (var ibt in incidentsByTechs)
            {
                if (ibt.Name != techName)
                {
                    lvIncidents.Items.Add(ibt.Name);
                    techName = ibt.Name;
                }
                else
                {
                    lvIncidents.Items.Add("");
                }

                lvIncidents.Items[i].SubItems.Add(ibt.ProductCode);
                lvIncidents.Items[i].SubItems.Add(
                    Convert.ToDateTime(ibt.DateOpened).ToShortDateString());
                lvIncidents.Items[i].SubItems.Add(
                    Convert.ToDateTime(ibt.DateClosed).ToShortDateString());
                lvIncidents.Items[i].SubItems.Add(ibt.Title);
                i += 1;


            }
        }
    }
}
