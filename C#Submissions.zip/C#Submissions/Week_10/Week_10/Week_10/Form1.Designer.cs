﻿namespace Week_10
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lvIncidents = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.txtTechId = new System.Windows.Forms.TextBox();
            this.txtTechName = new System.Windows.Forms.TextBox();
            this.txtincidentId = new System.Windows.Forms.TextBox();
            this.txtcustomerId = new System.Windows.Forms.TextBox();
            this.txtProductCode = new System.Windows.Forms.TextBox();
            this.txtProdutTitle = new System.Windows.Forms.TextBox();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.dateTimeEnd = new System.Windows.Forms.DateTimePicker();
            this.dateTimeStart = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // lvIncidents
            // 
            this.lvIncidents.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5});
            this.lvIncidents.HideSelection = false;
            this.lvIncidents.Location = new System.Drawing.Point(68, 313);
            this.lvIncidents.Name = "lvIncidents";
            this.lvIncidents.Size = new System.Drawing.Size(1675, 814);
            this.lvIncidents.TabIndex = 0;
            this.lvIncidents.UseCompatibleStateImageBehavior = false;
            this.lvIncidents.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Technician";
            this.columnHeader1.Width = 173;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Product";
            this.columnHeader2.Width = 154;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Date Opened";
            this.columnHeader3.Width = 152;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Date Closed";
            this.columnHeader4.Width = 162;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Title";
            this.columnHeader5.Width = 296;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(1259, 58);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(235, 49);
            this.btnAdd.TabIndex = 1;
            this.btnAdd.Text = "Add Incident Report";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.BtnAdd_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(1259, 145);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(235, 44);
            this.btnExit.TabIndex = 2;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            // 
            // txtTechId
            // 
            this.txtTechId.Location = new System.Drawing.Point(80, 76);
            this.txtTechId.Name = "txtTechId";
            this.txtTechId.Size = new System.Drawing.Size(122, 31);
            this.txtTechId.TabIndex = 3;
            this.txtTechId.Text = "ID";
            // 
            // txtTechName
            // 
            this.txtTechName.Location = new System.Drawing.Point(80, 132);
            this.txtTechName.Name = "txtTechName";
            this.txtTechName.Size = new System.Drawing.Size(122, 31);
            this.txtTechName.TabIndex = 4;
            this.txtTechName.Text = "Name";
            // 
            // txtincidentId
            // 
            this.txtincidentId.Location = new System.Drawing.Point(250, 76);
            this.txtincidentId.Name = "txtincidentId";
            this.txtincidentId.Size = new System.Drawing.Size(122, 31);
            this.txtincidentId.TabIndex = 5;
            // 
            // txtcustomerId
            // 
            this.txtcustomerId.Location = new System.Drawing.Point(250, 132);
            this.txtcustomerId.Name = "txtcustomerId";
            this.txtcustomerId.Size = new System.Drawing.Size(122, 31);
            this.txtcustomerId.TabIndex = 6;
            // 
            // txtProductCode
            // 
            this.txtProductCode.Location = new System.Drawing.Point(423, 76);
            this.txtProductCode.Name = "txtProductCode";
            this.txtProductCode.Size = new System.Drawing.Size(122, 31);
            this.txtProductCode.TabIndex = 7;
            // 
            // txtProdutTitle
            // 
            this.txtProdutTitle.Location = new System.Drawing.Point(646, 76);
            this.txtProdutTitle.Name = "txtProdutTitle";
            this.txtProdutTitle.Size = new System.Drawing.Size(122, 31);
            this.txtProdutTitle.TabIndex = 9;
            // 
            // txtDescription
            // 
            this.txtDescription.Location = new System.Drawing.Point(80, 194);
            this.txtDescription.Multiline = true;
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Size = new System.Drawing.Size(640, 89);
            this.txtDescription.TabIndex = 11;
            // 
            // dateTimeEnd
            // 
            this.dateTimeEnd.Location = new System.Drawing.Point(646, 130);
            this.dateTimeEnd.Name = "dateTimeEnd";
            this.dateTimeEnd.Size = new System.Drawing.Size(200, 31);
            this.dateTimeEnd.TabIndex = 12;
            // 
            // dateTimeStart
            // 
            this.dateTimeStart.Location = new System.Drawing.Point(423, 130);
            this.dateTimeStart.Name = "dateTimeStart";
            this.dateTimeStart.Size = new System.Drawing.Size(200, 31);
            this.dateTimeStart.TabIndex = 14;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2032, 1172);
            this.Controls.Add(this.dateTimeStart);
            this.Controls.Add(this.dateTimeEnd);
            this.Controls.Add(this.txtDescription);
            this.Controls.Add(this.txtProdutTitle);
            this.Controls.Add(this.txtProductCode);
            this.Controls.Add(this.txtcustomerId);
            this.Controls.Add(this.txtincidentId);
            this.Controls.Add(this.txtTechName);
            this.Controls.Add(this.txtTechId);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.lvIncidents);
            this.Name = "Form1";
            this.Text = "Incidents by Technician";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView lvIncidents;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.TextBox txtTechId;
        private System.Windows.Forms.TextBox txtTechName;
        private System.Windows.Forms.TextBox txtincidentId;
        private System.Windows.Forms.TextBox txtcustomerId;
        private System.Windows.Forms.TextBox txtProductCode;
        private System.Windows.Forms.TextBox txtProdutTitle;
        private System.Windows.Forms.TextBox txtDescription;
        private System.Windows.Forms.DateTimePicker dateTimeEnd;
        private System.Windows.Forms.DateTimePicker dateTimeStart;
    }
}

