﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week_10
{
    public class Incident
    {
        public int IncidentId { get; set; }

        public int CustomerId { get; set; } 

        public string ProductCode { get; set; }

        public int? TechId { get; set; }

        public DateTime? DateOpened { get; set; }

        public DateTime? DateClosed { get; set; }

        public string Title { get; set; }

        public string Description { get; set; }
    }
}
