﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LunchOrderApp
{
    public partial class Form1 : Form
    {
        static double ordertotal = 0.00;        

        public Form1()
        {
            InitializeComponent();
            radioButton1.Checked = true;            
        }

        private double getTax(double ordertotal) //calculates taxes 
        {
            return (ordertotal * 0.0775);                
        }
        private double getGrandTotal(double ordertotal)  //calculates grand total
        {
            return ((ordertotal * 0.0775)+ordertotal);
        }

        private void displayCost()  //displays the current cost in total, tax, and grand total, then cuts it into a string value
        {
            textBox1.Text = ordertotal.ToString("$#.##");
            textBox2.Text = getTax(ordertotal).ToString("$0.##");
            textBox3.Text = getGrandTotal(ordertotal).ToString("$0.##");
        }

        private double checkButtons() {  //confirms the amount to add onto an order with each add on. 
            

            if (radioButton1.Checked) {
                return 0.75;                
            }            
            else if (radioButton2.Checked)
            {
                return 0.50;               
            }           
            else if (radioButton3.Checked)
            {
                return 0.25;                
            }
            return 0;
        }

        private void unCheckBoxes() {  //this is the method to uncheck the add ons if the main course is changed
            checkBox1.Checked = false;
            checkBox2.Checked = false;
            checkBox3.Checked = false;
        }

        private void NewOrder()  //method to reset all values and reset the variables
        {
            ordertotal = 0.0;
            Application.Restart();
        }


        private void GroupBox3_Enter(object sender, EventArgs e)
        {           
            
        }

        private void GroupBox1_Enter(object sender, EventArgs e)
        {
            
        }

        private void GroupBox2_Enter(object sender, EventArgs e)
        {
            
        }

        private void CheckBox1_CheckedChanged(object sender, EventArgs e)
        {
            //confirms the status of the box, then subtracts or adds the add on values 
            if (checkBox1.Checked)
            {
                ordertotal += checkButtons();
                displayCost();
            }
            else if (!checkBox1.Checked)
            {
                ordertotal -= checkButtons();
                displayCost();
            }

        }

        private void CheckBox2_CheckedChanged(object sender, EventArgs e)
        {
            //confirms the status of the box, then subtracts or adds the add on values 
            if (checkBox2.Checked)
            {
                ordertotal += checkButtons();
                displayCost();
            }
            else if (!checkBox2.Checked)
            {
                ordertotal -= checkButtons();
                displayCost();
            }
        }

        private void CheckBox3_CheckedChanged(object sender, EventArgs e)
        {
            //confirms the status of the box, then subtracts or adds the add on values 
            if (checkBox3.Checked)
            {
                ordertotal += checkButtons();
                displayCost();
            }
            else if (!checkBox3.Checked)
            {
                ordertotal -= checkButtons();
                displayCost();
            }
        }

        private void PlaceOrder_Click(object sender, EventArgs e)
        {
            //Confirms the order and resets the application to start a new order.
            MessageBox.Show("Order has been submitted", "Order Confirmation");
            NewOrder();
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            //Confirms whether or not the user wants to exit. 
            DialogResult dialogResult = MessageBox.Show("Would you like to close the application?", "Close Application", MessageBoxButtons.YesNo);

            if (dialogResult == DialogResult.Yes)
            {
                this.Close();
            }
            else if (dialogResult == DialogResult.No)
            {
                return;
            }
        }

        private void Subtotal_TextChanged(object sender, EventArgs e)
        {

        }

        private void Tax_TextChanged(object sender, EventArgs e)
        {

        }

        private void OrderTotal_TextChanged(object sender, EventArgs e)
        {

        }

        private void hamburger_CheckedChanged(object sender, EventArgs e)
        {       
            //This changes the add-on values to hamburger related items, unchecks the boxes, and displays total cost
            RadioButton hamburger = sender as RadioButton;
            if (hamburger.Checked) {
                unCheckBoxes();
                groupBox2.Text = "Add-on items ($0.75/each)";
                checkBox1.Text = "Lettuce, tomato, and onions";
                checkBox2.Text = "Ketchup, mustard, and mayo";
                checkBox3.Text = "French fries";
                ordertotal = 6.95;
                displayCost();
            }
        }

        private void pizza_CheckedChanged(object sender, EventArgs e)
        {
            //This changes the add-on values to pizza related items, unchecks the boxes, and displays total cost
            RadioButton pizza = sender as RadioButton;
            if (pizza.Checked)
            {
                unCheckBoxes();
                groupBox2.Text = "Add-on items ($0.50/each)";
                checkBox1.Text = "Pepperoni";
                checkBox2.Text = "Sausage";
                checkBox3.Text = "Olives";
                ordertotal = 5.95;
                displayCost();
            }
        }

        private void salad_CheckedChanged(object sender, EventArgs e)
        {
            //This changes the add-on values to salad related items, unchecks the boxes, and displays total cost
            RadioButton salad = sender as RadioButton;
            if (salad.Checked)
            {
                unCheckBoxes();
                groupBox2.Text = "Add-on items ($0.25/each)";
                checkBox1.Text = "Croutons";
                checkBox2.Text = "Bacon bits";
                checkBox3.Text = "Bread sticks";
                ordertotal = 4.95;
                displayCost();
            }
        }

        private void CheckBox3_CheckStateChanged(object sender, EventArgs e)
        {

        }        
    }
}
