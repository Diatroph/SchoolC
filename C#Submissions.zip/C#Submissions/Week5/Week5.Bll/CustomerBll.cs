﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Week5.Data;

namespace Week5.Bll
{
    public static class CustomerBll
    {
        public static List<Customer> MakeCustomerList(Customer c, int count)
        {
            List<Customer> customerList = new List<Customer>();
            for(int i = 0; i<count; i++)
            {
                Customer cust = (Customer)c.Clone();
                customerList.Add(cust);
            }
            return customerList;
        }
            
    }
}
