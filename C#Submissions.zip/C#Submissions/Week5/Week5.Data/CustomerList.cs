﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Week5.Data
{
    /*interface IEnumerable<Customer>
    {
        
    }*/

    public class CustomerList<T> : IEnumerable<Customer>
    {
        private List<Customer> customers = new List<Customer>();
        //Below is the code copied from the text example. I am not sure exactly what it does...
        public IEnumerator<Customer> GetEnumerator()
        {
            foreach (Customer item in customers)
            {
                yield return item;
            }
        }

        System.Collections.IEnumerator
            System.Collections.IEnumerable.GetEnumerator()
        {
            throw new NotImplementedException();
        }

        public int COunt => customers.Count;

        public Customer this[int i] => customers[i];

        public void Add(Customer customer) => customers.Add(customer); 

    }
}
