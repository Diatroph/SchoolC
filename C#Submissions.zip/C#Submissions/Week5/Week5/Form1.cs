﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Week5.Bll;
using Week5.Data;
using Week5.Validator;

namespace Week5
{
    public partial class Form1 : Form
    {
        private Customer customer;
        
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnClone_Click(object sender, EventArgs e)
        {
            if (IsValidData())
            {
                int count = Convert.ToInt32(txtCopies.Text);
                CustomerList<Customer> customers = new CustomerList<Customer>();
                //customers = CustomerBll.MakeCustomerList(customer, count);     
                //Above is the old Code, below is the code to add the clones, not entirely sure what
                //the foreach loop down there does. 
                for (int i = 0; i < count; i++)
                {
                    customers.Add(customer);
                }

                lstCustomers.Items.Clear();
                
                foreach(Customer c in customers)
                {
                    lstCustomers.Items.Add(c.GetDisplayText());
                }
            }
        }

        private bool IsValidData()
        {
            return Validator.Validator.IsPresent(txtCopies)
            && Validator.Validator.IsInt32(txtCopies);
        }

        private void BtnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            customer = new Customer("John", "Mendez", "jmendez@occc.edu");
            lblCustomer.Text = customer.GetDisplayText();
        }
    }
}
