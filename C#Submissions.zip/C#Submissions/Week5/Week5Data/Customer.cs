﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Week5Data
{
    public class Customer : ICloneable
    {
        private string firstName;
        private string lastName;
        private string email;

        public Customer() { }

        public Customer(string fname, string lname, string email)
        {
            firstName = fname;
            lastName = lname;
            this.email = email;
        }

        public string FirstName {
            get
            {
                return firstName;
            }
            set
            {
                firstName = value;
            }
        }
        public string LastName {
            get
            {
                return lastName;
            }
            set
            {
                lastName = value;
            }
        }
        private string Email {
            get
            {
                return email;
            }
            set
            {
                email = value;
            }
        }

        public string GetDisplayText() =>
            firstName + " " + lastName + ", " + email;
        public object Clone()
        {
            return new Customer(this.FirstName, this.LastName, this.Email);
        }
    }
}
