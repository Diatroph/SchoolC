﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    public class SavingsAccount : Account
    {
        private double interest = 0.0;
        public SavingsAccount()
        {

        }

        public SavingsAccount(double balance, double interest): base(balance)
        {            
            this.interest = interest;
        }

        public void setInterest(double interest)
        {
            this.interest = interest;
        }

        public double getInterest()
        {
            return (this.interest/100);
        }

        public double calculateInterest() {            
            return (getBalance() * (this.interest/100)); 
        }
    }
}
