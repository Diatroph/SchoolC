﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    public class CheckingAccount : Account
    {
        private double fee = 2.00;
        public CheckingAccount()
        {

        }

        public CheckingAccount(double balance) : base(balance)
        {
            
        }     

        public double getFee()
        {
            return this.fee;
        }        
    }
}
