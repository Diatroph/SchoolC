﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public class Account
    {
        private double balance = 0.0;        

        public Account()
        {

        }

        public Account(double balance)
        {
            this.balance = balance;
        }

        public void setBalance(double balance)
        {
            this.balance = balance;
        }

        public double getBalance() {
            return this.balance;
        }

        public double Debit(double debit)
        {
            return (this.balance -= debit);
        }

        public double Credit(double credit)
        {
            return (this.balance += credit);
        }        
    }
}
