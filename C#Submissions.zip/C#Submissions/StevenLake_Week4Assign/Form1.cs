﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        //variables made public so I can call on them in multiple methods.
        CheckingAccount checkingAccount;
        SavingsAccount savingsAccount;

        public Form1()
        {
            InitializeComponent();
            groupBox2.Enabled = false;
            groupBox3.Enabled = false;
            
        }

        private double getDouble(String text) //This will catch any non-numeric values and convert them to 0.0, Also ensures value is positive. 
        {
            try
            {
                if (double.Parse(text) >= 0.0)
                {
                    return double.Parse(text);
                }
                else
                {
                    return 0.0;
                }
            }
            catch (Exception e) { return 0.0; }
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            //Creates a Savings Account with interest/initial desposit
            savingsAccount = new SavingsAccount(getDouble(textBox2.Text), getDouble(textBox1.Text)); //textbox1 = interest, textbox2 = initial balance
            //disabling groupbox to prevent any errors with what is displayed on the form
            groupBox1.Enabled = false;
            groupBox3.Enabled = true;
            textBox8.Text = savingsAccount.getBalance().ToString("#.##");
            label2.Text = String.Format("({0})", savingsAccount.getInterest().ToString("#.##%"));
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            //Creates a Checking Account with initial deposit. 
            checkingAccount = new CheckingAccount(getDouble(textBox3.Text)); //textbox 3 is initial balance
            //disabling groupbox to prevent any errors with what is displayed on the form                      
            groupBox4.Enabled = false;
            groupBox2.Enabled = true;
            textBox10.Text = checkingAccount.getBalance().ToString("#.##");
            label5.Text = String.Format("Transaction Fee {0}", checkingAccount.getFee().ToString("$#.##"));
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            //This button will revert the current savings account and reenable account creation. Also resets displayed values. 
            groupBox1.Enabled = true;
            groupBox3.Enabled = false;
            savingsAccount.setBalance(0.0);
            savingsAccount.setInterest(0.0);
            textBox4.Text = ("");
            textBox8.Text = savingsAccount.getBalance().ToString("#.##");
            label2.Text = String.Format("({0})", savingsAccount.getInterest().ToString("#.##%"));
        }

        private void Button6_Click(object sender, EventArgs e)
        {
            //This button will revert the current checking account and reenable account creation. Also resets displayed values. 
            groupBox4.Enabled = true;
            groupBox2.Enabled = false;
            checkingAccount.setBalance(0.0);
            textBox6.Text = ("");
            textBox10.Text = checkingAccount.getBalance().ToString("#.##");
        }

        private void Button5_Click(object sender, EventArgs e)
        {
            //Debits Savings
            if (getDouble(textBox4.Text) <= savingsAccount.getBalance())
            {
                if (approveDebit())
                {
                    checkingAccount.Debit(getDouble(textBox4.Text));
                    textBox8.Text = checkingAccount.getBalance().ToString("#.##");
                }
            }
            else
            {
                MessageBox.Show("This amount exceeds your balance", "Transaction Error");
            }                  
        }

        private void Button7_Click(object sender, EventArgs e)
        {
            //Debits Checking and includes the fee. 
            if (getDouble(textBox6.Text) <= (checkingAccount.getBalance()+checkingAccount.getFee()))
            {                
                if (approveDebit())
                {
                    checkingAccount.Debit(getDouble(textBox6.Text));
                    checkingAccount.Debit(checkingAccount.getFee());
                    textBox10.Text = checkingAccount.getBalance().ToString("#.##");
                }                
            }
            else
            {
                MessageBox.Show("This amount exceeds your balance", "Transaction Error");
            }            
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            //Credits Savings
            if (approveCredit())
            {
                savingsAccount.Credit(getDouble(textBox6.Text));
                textBox8.Text = savingsAccount.getBalance().ToString("#.##");
            }       
              
        }

        private void Button8_Click(object sender, EventArgs e)
        {
            //Credits Checking with fee charged as well
            if (approveCredit())
            {
                checkingAccount.Credit(getDouble(textBox6.Text));
                checkingAccount.Debit(checkingAccount.getFee());
                textBox10.Text = checkingAccount.getBalance().ToString("#.##");
            }                 
        }

        private void Button9_Click(object sender, EventArgs e)
        {
            //Calculates interest
            double x = savingsAccount.calculateInterest();
            savingsAccount.Credit(x);
            string y = "This account has been credited for the interest of $ ";
            MessageBox.Show(y + x.ToString("#.##"), "Interest Added");
            textBox8.Text = savingsAccount.getBalance().ToString("#.##");
        }

        private bool approveDebit() //determines if the user wants to debit or not. 
        {
            DialogResult dialogResult = MessageBox.Show("Do you want to debit this amount?", "Transaction Approval", MessageBoxButtons.YesNo);

            if (dialogResult == DialogResult.Yes)
            {
                return true;
            }
            else
            {                
                return false;
            }
        }

        private bool approveCredit() //determines if the user wants to credit or not. 
        {
            DialogResult dialogResult = MessageBox.Show("Do you want to credit this amount?", "Transaction Approval", MessageBoxButtons.YesNo);

            if (dialogResult == DialogResult.Yes)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
