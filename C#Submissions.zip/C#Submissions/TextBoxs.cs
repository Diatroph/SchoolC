﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AirplaneSeating
{
    public partial class Form1 : Form   {


        //core variables, j and k were originally part of a loop, but that wasnt working. 
        bool[] boolArray = new bool[10];
        string nextFlight = "The next flight leaves in three hours.";
        string fullFlight = "We're sorry, the flight is currently full. The next flight leaves in three hours.";
        string seatNumber = "Your seat number is : ";
        int j = 0;
        int k = 5;

        public Form1()
        {
            InitializeComponent();          

            //initialized the array to false
            for (int i = 0; i < boolArray.Length; i++) {
                boolArray[i] = false;
            }
        }     

        private void Button1_KeyPress(object sender, KeyPressEventArgs e)
        {
            Button1_Click(sender, e); //allows use of key 1 and calls that method, this did not work as expected
        }

        private void Button2_KeyPress(object sender, KeyPressEventArgs e)
        {
            Button2_Click(sender, e);//allows use of key 2 and calls that method, this did not work as expected
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            int firstClass = 5;//local variable to indicate how big first class is. 
            
            if (j < firstClass)//this will scan start the statement then assign a seat if one is available.
            {
                if (boolArray[j] == false)
                {
                    boolArray[j] = true;
                    MessageBox.Show(seatNumber + (j + 1), "Seat Confirmation");//(+1 for the correct seat output)
                    j++;
                    return;
                }               
            }
            else
            {
                if (j == 5 && k == 10)//this will scan whether or not the flight is full
                {
                    MessageBox.Show(fullFlight, "Next Flight Time Alert");
                    return;
                }
                else {
                    //displays a pop up asking if the customer wants to go to economy seating, if not, tells them next flight

                    DialogResult dialogResult = MessageBox.Show("Those seats are full, would you like to book economy seats?", "Seating Alert", MessageBoxButtons.YesNo);

                    if (dialogResult == DialogResult.Yes)
                    {
                        downgradeClass();
                    }
                    else if (dialogResult == DialogResult.No)
                    {
                        MessageBox.Show(nextFlight, "Next Flight Time Alert");
                        return;
                    }
                }
            }
            
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            int economy = 10;//local variable to indicate how big economy is, plus the 5 from first class. 

            if (k < economy)//this will scan start the statement then assign a seat if one is available.
            {
                if (boolArray[k] == false)
                {
                    boolArray[k] = true;
                    MessageBox.Show(seatNumber + (k + 1), "Seat Confirmation");
                    k++;
                    return;
                }
            }
            else
            {
                if (j == 5 && k == 10)//this will scan whether or not the flight is full
                {
                    MessageBox.Show(fullFlight, "Next Flight Time Alert");
                    return;
                }
                else
                {
                    //displays a pop up asking if the customer wants to go to economy seating, if not, tells them next flight
                    DialogResult dialogResult = MessageBox.Show("Those seats are full, would you like to book first class seats?", "Seating Alert", MessageBoxButtons.YesNo);
                    if (dialogResult == DialogResult.Yes)
                    {
                        upgradeClass();
                    }
                    else if (dialogResult == DialogResult.No)
                    {
                        MessageBox.Show(nextFlight, "Next Flight Time Alert");
                        return;
                    }
                }
            }
        }


        private void upgradeClass() {
            int firstClass = 5;            

            if (j < firstClass)//this will scan start the statement then assign a seat if one is available.
            {
                if (boolArray[j] == false)//this will book the customer's seat in first class 
                {
                    boolArray[j] = true;
                    MessageBox.Show(seatNumber + (j + 1), "Seat Confirmation");
                    j++;
                    return;
                }
                
            }
        }

        private void downgradeClass() {
            int economy = 10;
            
            if (k < economy)//this will scan start the statement then assign a seat if one is available.
            {
                if (boolArray[k] == false)//this will book the customer's seat in economy
                {
                    boolArray[k] = true;
                    MessageBox.Show(seatNumber + (k + 1), "Seat Confirmation");
                    k++;
                    return;
                }                
            }          
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < boolArray.Length; i++)
            {
                boolArray[i] = false;
            }
            j = 0;
            k = 5;
            return;
        }

        private void Button2_KeyDown(object sender, KeyEventArgs e)
        {
            
        }

        private void Button1_KeyDown(object sender, KeyEventArgs e)
        {
            
        }
    }
}
