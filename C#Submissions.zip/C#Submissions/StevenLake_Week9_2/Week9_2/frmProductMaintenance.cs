﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week9_2
{
    public partial class frmProductMaintenance : Form
    {
        private Product product;
        public frmProductMaintenance()
        {
            InitializeComponent();
        }

        private void BtnGetProduct_Click(object sender, EventArgs e)
        {
            if(Validator.IsPresent(txtProductCode))
            {
                this.GetProduct(txtProductCode.Text);
                if(product == null)
                {
                    MessageBox.Show("No Product found with this Code. Please Try Again",
                        "No Product Found");
                }
                else
                {
                    this.DisplayProduct();
                }
            }
        }

        private void DisplayProduct()
        {
            txtProductDescription.Text = product.Description;  //?
            txtPrice.Text = product.Price.ToString("c2");
            btnModify.Enabled = true;
            btnDelete.Enabled = true;
        }

        private void GetProduct(string productCode)
        {
            try
            {
                product = ProductDB.GetProduct(productCode);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, ex.GetType().ToString());
            }
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            frmAddModifyProduct addModifyProduct = new frmAddModifyProduct();
            addModifyProduct.addProduct = true;
            DialogResult result = addModifyProduct.ShowDialog();

            if(result == DialogResult.OK)
            {
                product = addModifyProduct.product;
                //txtProductCode.Text = product.Code;
                //this.DisplayProduct();
            }
            /*else if (result == DialogResult.Retry)
            {
                this.GetProduct(product.Code);
                if (product != null)
                    this.BtnGetProduct_Click(sender, e);
                else
                    this.ClearControls();
            }*/

        }

        private void BtnModify_Click(object sender, EventArgs e)
        {
            frmAddModifyProduct addModifyProduct = new frmAddModifyProduct();
            addModifyProduct.addProduct = false;
            addModifyProduct.product = product;
            DialogResult result = addModifyProduct.ShowDialog();
            if(result == DialogResult.OK)
            {
                product = addModifyProduct.product;
                this.DisplayProduct();
            }
            else if(result == DialogResult.Retry)
            {
                this.GetProduct(product.Code);
                if (product != null)
                    this.BtnGetProduct_Click(sender, e);
                else
                    this.ClearControls();
            }
        }

        private void ClearControls()
        {
            txtProductCode.Text = "";
            txtProductDescription.Text = "";
            txtPrice.Text = "";
            btnModify.Enabled = false;
            btnDelete.Enabled = false;
            txtProductCode.Focus();
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (!ProductDB.DeleteProduct(product))
                {
                    MessageBox.Show("A Product with that code already exists. ",
                        "Database Error");
                }
                else
                {
                    MessageBox.Show("Product was deleted", "Database System");
                    ClearControls();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, ex.GetType().ToString());
            }
        }

        private void BtnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void TxtProductCode_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
