﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week9_2
{
    public partial class frmAddModifyProduct : Form
    {
        public bool addProduct;
        public Product product;

        public frmAddModifyProduct()
        {
            InitializeComponent();
        }

        private void FrmAddModifyProduct_Load(object sender, EventArgs e)
        {
            if(addProduct)
            {                
                this.Text = "Add Product";                
                txtProductCode.ReadOnly = false;
                txtProductCode.TabStop = true;
                txtProductCode.Focus();
                this.DisplayProduct();
            }
            else
            {
                this.Text = "Modify Product";
                txtProductCode.ReadOnly = true;
                txtProductCode.TabStop = false;
                txtProductDescription.Focus();
                this.DisplayProduct();
            }
        }


        private void DisplayProduct()
        {
            txtProductCode.Text = product.Code;
            txtProductDescription.Text = product.Description;
            txtPrice.Text = product.Price.ToString();

        }

        private void BtnAccept_Click(object sender, EventArgs e)
        {
            if(IsValidData())
            {
                if (addProduct)  
                {
                    Product product = new Product();
                    product.Code = txtProductCode.Text;
                    product.Description = txtProductDescription.Text;
                    product.Price = Convert.ToDecimal(txtPrice.Text);
                    try
                    {
                        if (!ProductDB.AddProduct(product))
                        {
                            MessageBox.Show("A Product with that code already exists. ",
                                "Database Error");
                            this.DialogResult = DialogResult.Retry;
                        }
                        else
                        {
                            this.DialogResult = DialogResult.OK;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, ex.GetType().ToString());
                    }
                }
                else
                {
                    Product newProduct = new Product();
                    newProduct.Code = txtProductCode.Text;
                    newProduct.Description = txtProductDescription.Text;
                    newProduct.Price = Convert.ToDecimal(txtPrice.Text);
                    try
                    {
                        if (!ProductDB.UpdateProduct(product, newProduct))
                        {
                            MessageBox.Show("Another user Updated or Deleted that Product ",
                                "Database Error");
                            this.DialogResult = DialogResult.Retry;
                        }
                        else
                        {
                            this.DialogResult = DialogResult.OK;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, ex.GetType().ToString());
                    }
                }
            }
        }

        private bool IsValidData()
        {
            return
                Validator.IsPresent(txtProductCode) &&
                Validator.IsPresent(txtProductDescription) &&
                Validator.IsPresent(txtPrice) &&
                Validator.IsDecimal(txtPrice);

        }

        private void TxtProductCode_TextChanged(object sender, EventArgs e)
        {

        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
