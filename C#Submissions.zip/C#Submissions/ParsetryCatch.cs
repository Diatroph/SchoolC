﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week1Project
{
    public partial class Form1 : Form
    {

        //primary variables
        double tolls = 0.0;
        double fees = 0.0;
        double miles = 0.0;
        double gas = 0.0;
        double MPG = 0.0;        
        public Form1()
        {
            InitializeComponent();
        }           


        private void SubmitButton_Click(object sender, EventArgs e)
        {
            //These fields bring the values from the screen into the variables once the submit button is pressed
            tolls = getDouble(TollsPerDay.Text);
            fees = getDouble(DailyParkingFees.Text);
            MPG = getDouble(AverageMilePerGallon.Text);
            gas = getDouble(CostPerGallon.Text);
            miles = getDouble(TotalMilesDriven.Text);

            //the adding of the currencies
            double total = 0.0;
            total = ((tolls + fees) + ((miles / MPG) * gas));

            //this outputs the total to the 6th text box. Then resets the variables to zero incase of a double submit.  
            TotalExpensesDaily.Text = total.ToString();
            total = 0.0;
            miles = 0.0;
            gas = 0.0;
            MPG = 0.0;
            tolls = 0.0;
            fees = 0.0;
        }
		
		private double getDouble(String text) //This will catch any non-numeric values and convert them to 0.0
		{
			try{
                return double.Parse(text);
			}
			catch(Exception e) { return 0.0; }
		}

        private void TollsPerDay_TextChanged(object sender, EventArgs e)
        {
           	 //values moved to submit button since textChanged is a strange method  
        }

        private void DailyParkingFees_TextChanged(object sender, EventArgs e)
        {
            //values moved to submit button since textChanged is a strange method  
        }

        private void AverageMilePerGallon_TextChanged(object sender, EventArgs e)
        {
            //values moved to submit button since textChanged is a strange method  
        }

        private void CostPerGallon_TextChanged(object sender, EventArgs e)
        {
            //values moved to submit button since textChanged is a strange method  
        }

        private void TotalMilesDriven_TextChanged(object sender, EventArgs e)
        {
            //values moved to submit button since textChanged is a strange method  
        }

        private void Label1_Click(object sender, EventArgs e)
        {
            //nothing should be changing here, label1 is the Total Miles Driven
        }

        private void Label2_Click(object sender, EventArgs e)
        {
            //nothing should be changing here, label2 is the Cost Per Gallon
        }

        private void Label3_Click(object sender, EventArgs e)
        {
            //nothing should be changing here, label3 is the Average Miles per gallon
        }

        private void Label4_Click(object sender, EventArgs e)
        {
            //nothing should be changing here, label4 is the Parking Fees
        }

        private void Label5_Click(object sender, EventArgs e)
        {
            //nothing should be changing here, label5 is the Toll Costs 
        }

        private void TotalExpensesDaily_TextChanged(object sender, EventArgs e)
        {
            //values moved to submit button since textChanged is a strange method  
        }

        private void Label6_Click(object sender, EventArgs e)
        {
            //nothing should be changing here, label6 is the Total Expense Daily
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //don't know what goes here
        }      

        private void SubmitButton_MouseClick(object sender, MouseEventArgs e)
        {
            //see submit at the top. 
        }
    }
}
