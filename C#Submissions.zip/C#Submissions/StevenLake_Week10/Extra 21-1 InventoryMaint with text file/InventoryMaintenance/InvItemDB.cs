using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace InventoryMaintenance
{
    public static class InvItemDB
    {
        private const string Path = @"..\..\InventoryItems.txt";

        public static List<InvItem> GetItems()
        {            
            List<InvItem> items = new List<InvItem>();
            FileStream fileStream = null;
            StreamReader textFile = null;

            //create a streamreader object with a filestream object for txt file, (need path) 
            //file should be opened, or created if it does not exist (readonly)

            //now the code should fill each line....so it fills it into a for loop

            //then close the stream

            try
            {
                fileStream = new FileStream(Path, FileMode.OpenOrCreate, FileAccess.Read); //filemode open or create? of course change access
                textFile = new StreamReader(fileStream);

                while (textFile.Peek() != -1)   //the hell is peek? 
                {
                    string row = textFile.ReadLine();
                    if (row != null)
                    {
                        string[] columns = row.Split('|');
                        InvItem item = new InvItem
                        {
                            ItemNo = Convert.ToInt32(columns[0]),
                            Description = columns[1],
                            Price = Convert.ToDecimal(columns[2])

                        };
                        items.Add(item);   //might need to be changed? Update? 
                    }
                }

            }                      
            finally
            {
                textFile.Close();
            }



           

            return items;
        }

        public static void SaveItems(List<InvItem> items)
        {            
            StreamWriter textFile = new StreamWriter(new FileStream(Path, FileMode.Create, FileAccess.Write));
            foreach (InvItem item in items)
            {
                textFile.Write(item.ItemNo + "|");
                textFile.Write(item.Description + "|");
                textFile.WriteLine(item.Price);
            }

            textFile.Close();            
        }
    }
}
